# Release Notes (1.0.0)

## Version `1.0.0`
> Release: `11-14-2022`

NEW create_model.ipynb
- Responsible for training, creating/loading models for denoising

Added the ff datasets:
- data/all_none_fs1024_e06.npy
- data/all_none_fs1024_e24.npy