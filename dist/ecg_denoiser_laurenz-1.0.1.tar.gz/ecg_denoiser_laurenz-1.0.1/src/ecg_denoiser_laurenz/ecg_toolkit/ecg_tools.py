# imports
import wfdb
import peakutils
import numpy as np
import pandas as pd
import tensorflow as tf
# froms
from sklearn import preprocessing # for normalizing data
# For test data splitting
from sklearn.model_selection import train_test_split




def get_data_sets(sigs, test_size=0.2):
    x_train, x_test = train_test_split( sigs[:], test_size=test_size)
    x_train = x_train.reshape(x_train.shape[0], x_train.shape[1], 1)
    x_test = x_test.reshape(x_test.shape[0], x_test.shape[1], 1)
    return x_train, x_test

# COMPUTE FOR AVERAGE

def get_max_abs(sigs):
    max_val = 0
    for i in range(sigs.shape[0]):
        for j in range(sigs.shape[1]):
            if abs(sigs[i][j]) > max_val:
                max_val = abs(sigs[i][j])
    # return max_val
    return max_val

def get_avg(sigs):
    # get average value
    sums = 0
    avg = 0

    for i in range(sigs.shape[0]):
        for j in range(sigs.shape[1]):
            sums = sigs[i][j] + sums
    avg = sums / (sigs.shape[0] * sigs.shape[1])
    # return average
    return avg

def normalize(sigs):
    # subtract by avg value / max of absolute value
    #  e.g.: [sigs](-5.635) -  [avg](-8.70) / 9.135 = -1.569
    avg = get_avg(sigs)
    max_val = get_max_abs(sigs)
    normed = np.zeros(shape=(sigs.shape[0], sigs.shape[1]))

    for i in range(sigs.shape[0]):
        for j in range(sigs.shape[1]):
            normed[i][j] = (sigs[i][j] - avg) / max_val

    return normed

def per_chunk_max_val(sig):
    max_val = 0
    for i in range(sig.shape[0]):
            if abs(sig[i]) > max_val:
                max_val = abs(sig[i])
    
    return max_val

def per_chunk_avg(sig):
    sums = 0
    avg = sig.shape[0]
    for i in range(len(sig)):
        sums = sums + sig[i]
    avg = sums / avg

    return avg

def per_chunk_norm(sig):
    avg = per_chunk_avg(sig)
    max_abs_val = per_chunk_max_val(sig)
    # print("average " + str(avg) + "||" + "max_abs " + str(max_val)) 
    normed = np.zeros(shape=(sig.shape[0]))
    for i in range( len(sig) ):
        normed[i] = (sig[i] - avg) / max_abs_val
    
    return normed
    



def normalize_by_chunks(sigs):
    """
    Normalizes ecg signal based on sampling frequency chunk (e.g. denominator of the mean is the sampling frequency and not the entire ecg signal)

    Returns::

        sigs (nd array): normalized ECG signal

    Paramter::

        sigs (nd array): original ECG signal
    """
    for i in range(sigs.shape[0]):
        sigs[i] = per_chunk_norm(sigs[i])

    return sigs


def norm_sig( ecg_set ):
    ecg_set_normed = ecg_set
    
    for i, sig in enumerate(ecg_set):
        sig = norm_global_prime(sig)
        ecg_set_normed[i] = sig
    
    return ecg_set_normed

def norm_global( x ):
    """
    Normalized from [0,1] [min, max]
    """
    x_prime = (x - x.min()) / (x.max() - x.min() )
    return x_prime

def norm_global_prime( x ):
    """
    Normalized from [-1,1] [min, max] (uses norm_global(x) )
    """
    x = norm_global(x)
    x_prime = (2*x)-1
    return x_prime



def load_signal(data_name, folder='ecg_data/', v_fields=False, channel=1):
    """
    Loads signals and fields from a ``WFDB.RDSAMP``

    Returns:
        1D array of signals (entire record)
        signals, fields (from wfdb.rdsamp).

        Usage:
            signals, fields = wfdb.rdsamp(...)

    Parameters:

        data_name (str): File name from MIT-BIH (e.g. ``100``, ``124e06``).
        folder (str): folder directory from within this notebook, add '/' at the end (e.g. ```ecg_data```)
        v_fields (bool): True to have function print signal's fields attribute

    Example:
        load_signal('100', 'ecg_data'/)
    """
    file_address = folder + data_name
    signals, fields = wfdb.rdsamp(file_address, channels=[channel])
    if v_fields == True:
        print("Printing fields information of the signal: ")
        print(fields)
    # return signals from the sample
    return signals




def load_signal_ann(data_name, folder='ecg_data/', v_fields=False, channel=1):
    """
    Loads signals and fields from a ``WFDB.RDSAMP``

    Returns:
        1D array of signals (entire record)
        signals, fields (from wfdb.rdsamp).

        Usage:
            signals, fields = wfdb.rdsamp(...)

    Parameters:

        data_name (str): File name from MIT-BIH (e.g. ``100``, ``124e06``).
        folder (str): folder directory from within this notebook, add '/' at the end (e.g. ```ecg_data```)
        v_fields (bool): True to have function print signal's fields attribute

    Example:
        load_signal('100', 'ecg_data'/)
    """
    file_address = folder + data_name
    signals, fields = wfdb.rdsamp(file_address, channels=[channel])
    if v_fields == True:
        print("Printing fields information of the signal: ")
        print(fields)
    # return signals from the sample
    return signals, fields



def get_samples(data_name, samp_freq=360, channel=0, norm_type=''):
    """
    Returns:

        signal (list): 2D array-like list [x][y] (not numpy) where first index is chunks and the 2nd index contains sample points from a single iteration determined by your cycle_len.
        The selected channel will automatically be V1

    Parameters::

        data_name (str): File name to be accessed (from MIT-BIH/Physionet) (e.g. ``100``, ``124e06``)
        samp_freq (int): Sample frequecy determined by you source 
        channel (int): Channel from the signal to use
        norm_type (str): Default is '', options are ``chunks`` and ``all``. Chunks option is divided by sampling frequency, all option is dividing by average of all datapoints in the entire signal

    Example:

        get_samples(data_name='100', samp_freq=360)
    """
    # load the signal via wfdb
    signal = load_signal(data_name=data_name, channel=channel)
    
    chunks = int(len(signal) / samp_freq)
    
    signal_list = np.zeros(shape=(chunks, samp_freq))
    
    sig_counter = 0
    for i in range(chunks):
        for j in range(samp_freq):
            signal_list[i][j] = signal[sig_counter]
            sig_counter = sig_counter + 1

    # Perform normalization.
    # normalization per chunk (normalizes data points as divided by sampling frequency)
    if str.lower(norm_type) == 'chunks' or str.lower(norm_type) == 'chunk':
        signal_list = normalize_by_chunks(signal_list)
    if str.lower(norm_type) == 'all':
        signal_list = normalize(signal_list)
    if str.lower(norm_type) == 'none':
        pass

    return signal_list




# Default GET_ECG method to use. Don't use others anymore huhu
def get_ecg_with_split(data_name, samp_freq=360, norm_type='chunks', channel=1):
    """
    DEFAULT GET_ECG METHOD TO USE
    
    Use when samp_freq is not 360 (specifically the 1024 sampling frequency)

    Returns:
        noised_seg, clean_seg (Numpy Array):
            Wherein both arrays contains time-specific segments of noise and untouched ECG from the NST generator.
    """
    # load everything with a sampling frequency of 360 (easier to split)
    x = get_samples(data_name, samp_freq=360, channel=channel, norm_type='') # must not normalize in this part yet
    # Split into two (using 360 as sampling frequency as 360Hz == 1 second)
    noised_seg, clean_seg = split_ecg_segments(x)
    # Flatten the arrays noised_seg and clean_seg into 1D
    noised_seg = noised_seg.flatten()
    clean_seg = clean_seg.flatten()
    # Once flatten, return both ECG's according to their sampling frequency
    # Get the appropriate length for chunks first
    chunks_noised = int( len(noised_seg) / samp_freq )
    chunks_clean = int( len(clean_seg) / samp_freq )
    chunks = 0
    # Assures that the smaller chunk size is followed for consistency (esp during training). 
    if chunks_noised < chunks_clean:
        chunks = chunks_noised
    elif chunks_noised > chunks_clean:
        chunks = chunks_clean
    else:
        chunks = chunks_noised
    # create the np arrays to be returned
    noised_seg_new = np.zeros( (int(chunks/2), samp_freq) ) # why + 1, idk yet
    clean_seg_new = np.zeros( (int(chunks/2), samp_freq) )
    # Proceed to migrate into 2D Arrays
    for i in range( chunks-1 ):
        if i % 2 == 0:
            noised_seg_new[ int(i/2) ] = noised_seg[ (samp_freq*i):((samp_freq*i)+samp_freq) ]
        else:
            clean_seg_new[ int(i/2 )] = clean_seg[ (samp_freq*i):((samp_freq*i)+samp_freq) ]
    
    # Perform normalization.
    # normalization per chunk (normalizes data points as divided by sampling frequency)
    if str.lower(norm_type) == 'chunks' or str.lower(norm_type) == 'chunk':
        # noised_seg_new = normalize_by_chunks(noised_seg_new)
        # clean_seg_new = normalize_by_chunks(clean_seg_new)
        noised_seg_new = norm_sig(noised_seg_new)
        clean_seg_new = norm_sig(clean_seg_new)
    if str.lower(norm_type) == 'all':
        noised_seg_new = normalize(noised_seg_new)
        clean_seg_new = normalize(clean_seg_new)
    if str.lower(norm_type) == 'none':
        pass
    # Reshape ready for training
    clean_seg_new = clean_seg_new.reshape( (clean_seg_new.shape[0], clean_seg_new.shape[1], 1) )
    noised_seg_new = noised_seg_new.reshape( (noised_seg_new.shape[0], noised_seg_new.shape[1], 1) )
    return noised_seg_new, clean_seg_new




def get_beats(data_name, cycles, cycle_len=360, samp_start=124000):
    """ 
    Returns:
        (list): 
            2D array-like list (not numpy array) where first index contains partitions of the entire signal (determined by ``cycles``) and 2nd index contains sample points determined by the ``cycle_len``

        The beats are determined with R-peaks in the middle  
    
    Parameters::

        data_name (str): File name to be accessed (from MIT-BIH/Physionet) (e.g. ``100``, ``124e06``)
        cycles (int): How many heartbeat cycles or partitions to be made from the signal.  

    """
    file_load = 'ecg_data/' + data_name
    # get signals from the sample
    signals_clean, fields_clean = wfdb.rdsamp(file_load, sampfrom=samp_start, channels=[1])    
    signals_temp = signals_clean[:,0] # easier way to flatten
    print(fields_clean)
    # Gets the r-peak of the entire signal
    peak_index = peakutils.indexes(signals_temp, thres=0.3, min_dist=300)
    # Get only n cardiac cycles determined by cycles argument
    # e.g. cycles = 10 will get from indexes [1:11], +1 is added as [0] will be discarded thus starting with [1]
    peak_index = peak_index[1:cycles+1]
    # Break into 30 cycles
    sc_list = np.zeros(shape=(len(peak_index),cycle_len)) # create temp variable to store all signals in groups of 30
    # populate by using peak index
    for i in range(len(peak_index)):    
        j_start = peak_index[i]-(cycle_len/2)
        if j_start < 0:
            j_start = 0
        for j in range(cycle_len):        
            jx = int(j_start + j)
            sc_list[i][j] = signals_clean[jx]
    # return a 2d array shaped (cycles, cycle_len)
    return sc_list




# Runs fas but needs optimization to make it shorter
def split_noisy_clean(ecg_data, start_minute=5):
    """
    Use split_ecg_segments instead this one 
    """
    noised_chunk = 0
    clean_chunk = 0
    chunks = 0 
    # starting noise generated
    start_minute = 5
    # How many usable 2-minute interval chunks are usable (rounded down)
    usable_chunks = int(((ecg_data.shape[0] - 300) / 120))
    # create a shape to be exported
    noised_segments = np.zeros( shape=( int((usable_chunks/2))*120, ecg_data.shape[1] ) )
    clean_segments = np.zeros( shape=( int((usable_chunks/2))*120, ecg_data.shape[1] ) )

    for i in range(usable_chunks):
        chunks = 60 * (start_minute + (i * 2))
        # make this for loop part look cleaner
        for j in range(120):
            if i % 2 == 0:                
                noised_segments[noised_chunk] = ecg_data[ chunks ]
                noised_chunk = noised_chunk + 1
            else:
                clean_segments[clean_chunk] = ecg_data[ chunks ]
                clean_chunk = clean_chunk + 1
            chunks = chunks + 1

    return noised_segments, clean_segments




def load_all_ecg_file(ecg_file):
    """
    Unfortunately, the generated files already have sampling frequency into it but not normalized (sad)
    """
    ecg_data = np.load(ecg_file)
    ecg_data = np.reshape( ecg_data, newshape=(ecg_data.shape[0], ecg_data.shape[1]) )
    ecg_data = normalize_by_chunks(ecg_data)
    ecg_data = np.reshape( ecg_data, newshape=(ecg_data.shape[0], ecg_data.shape[1], 1) )
    return ecg_data




def split_ecg_segments(ecg_data, start_minute=5):
    """
    WORKS WITH 360 SAMP FREQUENCY ONLY
    Returns 2 Numpy arrays consisting of noised segments and cleaned segments.
    Returned segments are based on the noise introduced by the NST script wherein 2 minutes of
    noised signals are followed by 2 minutes of clean signals (then repeat steps alternating).
    The resulting Numpy arrays are reshaped already in here so that it can be used directly with
    Autoencoder.model.fit(x).

    Returns:

        noised_seg (Numpy Array):
            Contiguous noised segments in the input ECG signal by NST
        
        clean_seg (Numpy Array):
            Contiguous clean segments in the input ECG untouched by NST

    """
    # How many usable 2-minute interval chunks are usable (rounded down) (Basically available sample points starting from the 5th-minute mark)
    # ISSUE: THE '300' USED IN HERE REFLECTS WHEN SAMPLING FREQUENCY IS 360 (THUS 1 SECOND) BUT DOES NOT PROPERLY REFLECT IF 
    # SAMPLING FREQUENCY IS 1024 WHERE 300 DOES NOT ANYMORE REFLECT THE 5TH MINUTE AS 1024 IS IS AROUND 2.88 SECONDS
    usable_chunks = int(((ecg_data.shape[0] - 300) / 120))
    # chunk size for the noised and clean segments
    segment_size = int( (usable_chunks/2) * 120 )
    # According to MIT-BIH, two minute intervals of noised and clean data will be generated by the NST script. This function assigns a 
    # contiguous version of those intervals in the variables below that will be returned
    noised_seg = np.zeros( shape=(segment_size, ecg_data.shape[1]) )
    clean_seg = np.zeros( shape=(segment_size, ecg_data.shape[1]) )
    # counters
    ecg_chunk_start = 60 * start_minute
    noised_chunk_start = 0
    clean_chunk_start = 0
    
    for i in range(usable_chunks):
        if i % 2 == 0:
            noised_seg[ noised_chunk_start:(noised_chunk_start+120) ] = ecg_data[ ecg_chunk_start:ecg_chunk_start+120 ]
            noised_chunk_start = noised_chunk_start+120
        else:
            clean_seg[ clean_chunk_start:(clean_chunk_start+120) ] = ecg_data[ ecg_chunk_start:ecg_chunk_start+120 ]
            clean_chunk_start = clean_chunk_start+120
        ecg_chunk_start = ecg_chunk_start+120

    noised_seg = noised_seg.reshape( (noised_seg.shape[0], noised_seg.shape[1], 1) )
    clean_seg = clean_seg.reshape( (clean_seg.shape[0], clean_seg.shape[1], 1) )

    return noised_seg, clean_seg




class ecg_data_sets:
    """
    Takes a while to load, call during start
    """
    def __init__(self, samp_freq=360, norm_type="chunks"):
        # ECG124, to be used for training
        self.ecg124_24 = get_samples('124e24', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_18 = get_samples('124e18', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_12 = get_samples('124e12', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_06 = get_samples('124e06', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_00 = get_samples('124e00', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_6 = get_samples('124e_6', samp_freq=samp_freq, norm_type=norm_type)
        # Used for visual inspection and evaluation
        # 124
        self.ecg124_24 = get_samples('124e24', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_18 = get_samples('124e18', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_12 = get_samples('124e12', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_06 = get_samples('124e06', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_00 = get_samples('124e00', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg124_6 = get_samples('124e_6', samp_freq=samp_freq, norm_type=norm_type)
        # 100
        self.ecg100_24 = get_samples('100e24', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg100_18 = get_samples('100e18', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg100_12 = get_samples('100e12', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg100_06 = get_samples('100e06', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg100_00 = get_samples('100e00', samp_freq=samp_freq, norm_type=norm_type)
        self.ecg100_6 = get_samples('100e_6', samp_freq=samp_freq, norm_type=norm_type)




# class ecg_split_data_sets:
#     """
#     Loads a bit faster than the other one

#     Uses each existing ECG record, then proceeds to use signals from 5 minute onwards then splits them into the alternating
#     noisy/clean segments as stated by the MIT-BIH NST generator script.

#     Returns::    
#         (nd array) : ns_1xxeyy, cs_1xxeyy where x is record no. and y is noise level (from n6 to 24)


#     Parameters::
#         samp_freq (int): sampling frequency used by the record (default 360)
#         norm_type (str): chunks, all, none/''
#     """
#     def __init__(self, samp_freq=360, norm_type='chunks'):
#         self.ns_100e24, self.cs_100e24 = get_ecg_with_split('100e24', samp_freq, channel=0,norm_type=norm_type)
#         self.ns_100e18, self.cs_100e18 = get_ecg_with_split('100e18', samp_freq, channel=0,norm_type=norm_type)
#         self.ns_100e12, self.cs_100e12 = get_ecg_with_split('100e12', samp_freq, channel=0,norm_type=norm_type)
#         self.ns_100e06, self.cs_100e06 = get_ecg_with_split('100e06', samp_freq, channel=0,norm_type=norm_type)
#         self.ns_100e00, self.cs_100e00 = get_ecg_with_split('100e00', samp_freq, channel=0,norm_type=norm_type)
#         self.ns_100en6, self.cs_100en6 = get_ecg_with_split('100e_6', samp_freq, channel=0,norm_type=norm_type)

#         self.ns_101e24, self.cs_101e24 = get_ecg_with_split('101e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_101e18, self.cs_101e18 = get_ecg_with_split('101e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_101e12, self.cs_101e12 = get_ecg_with_split('101e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_101e06, self.cs_101e06 = get_ecg_with_split('101e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_101e00, self.cs_101e00 = get_ecg_with_split('101e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_101en6, self.cs_101en6 = get_ecg_with_split('101e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         ## Record 102 has no ML2
#         # self.ns_102e24, self.cs_102e24 = get_ecg_with_split('102e24', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_102e18, self.cs_102e18 = get_ecg_with_split('102e18', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_102e12, self.cs_102e12 = get_ecg_with_split('102e12', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_102e06, self.cs_102e06 = get_ecg_with_split('102e06', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_102e00, self.cs_102e00 = get_ecg_with_split('102e00', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_102en6, self.cs_102en6 = get_ecg_with_split('102e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_103e24, self.cs_103e24 = get_ecg_with_split('103e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_103e18, self.cs_103e18 = get_ecg_with_split('103e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_103e12, self.cs_103e12 = get_ecg_with_split('103e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_103e06, self.cs_103e06 = get_ecg_with_split('103e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_103e00, self.cs_103e00 = get_ecg_with_split('103e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_103en6, self.cs_103en6 = get_ecg_with_split('103e_6', samp_freq,channel=0, norm_type=norm_type)

#         ## RECORD 104 HAS NO ML2
#         # self.ns_104e24, self.cs_104e24 = get_ecg_with_split('104e24', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_104e18, self.cs_104e18 = get_ecg_with_split('104e18', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_104e12, self.cs_104e12 = get_ecg_with_split('104e12', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_104e06, self.cs_104e06 = get_ecg_with_split('104e06', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_104e00, self.cs_104e00 = get_ecg_with_split('104e00', samp_freq,channel=0, norm_type=norm_type)
#         # self.ns_104en6, self.cs_104en6 = get_ecg_with_split('104e_6', samp_freq,channel=0, norm_type=norm_type)


#         self.ns_105e24, self.cs_105e24 = get_ecg_with_split('105e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_105e18, self.cs_105e18 = get_ecg_with_split('105e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_105e12, self.cs_105e12 = get_ecg_with_split('105e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_105e06, self.cs_105e06 = get_ecg_with_split('105e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_105e00, self.cs_105e00 = get_ecg_with_split('105e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_105en6, self.cs_105en6 = get_ecg_with_split('105e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_106e24, self.cs_106e24 = get_ecg_with_split('106e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_106e18, self.cs_106e18 = get_ecg_with_split('106e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_106e12, self.cs_106e12 = get_ecg_with_split('106e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_106e06, self.cs_106e06 = get_ecg_with_split('106e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_106e00, self.cs_106e00 = get_ecg_with_split('106e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_106en6, self.cs_106en6 = get_ecg_with_split('106e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_107e24, self.cs_107e24 = get_ecg_with_split('107e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_107e18, self.cs_107e18 = get_ecg_with_split('107e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_107e12, self.cs_107e12 = get_ecg_with_split('107e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_107e06, self.cs_107e06 = get_ecg_with_split('107e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_107e00, self.cs_107e00 = get_ecg_with_split('107e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_107en6, self.cs_107en6 = get_ecg_with_split('107e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_108e24, self.cs_108e24 = get_ecg_with_split('108e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_108e18, self.cs_108e18 = get_ecg_with_split('108e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_108e12, self.cs_108e12 = get_ecg_with_split('108e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_108e06, self.cs_108e06 = get_ecg_with_split('108e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_108e00, self.cs_108e00 = get_ecg_with_split('108e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_108en6, self.cs_108en6 = get_ecg_with_split('108e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_109e24, self.cs_109e24 = get_ecg_with_split('109e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_109e18, self.cs_109e18 = get_ecg_with_split('109e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_109e12, self.cs_109e12 = get_ecg_with_split('109e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_109e06, self.cs_109e06 = get_ecg_with_split('109e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_109e00, self.cs_109e00 = get_ecg_with_split('109e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_109en6, self.cs_109en6 = get_ecg_with_split('109e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_111e24, self.cs_111e24 = get_ecg_with_split('111e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_111e18, self.cs_111e18 = get_ecg_with_split('111e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_111e12, self.cs_111e12 = get_ecg_with_split('111e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_111e06, self.cs_111e06 = get_ecg_with_split('111e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_111e00, self.cs_111e00 = get_ecg_with_split('111e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_111en6, self.cs_111en6 = get_ecg_with_split('111e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_112e24, self.cs_112e24 = get_ecg_with_split('112e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_112e18, self.cs_112e18 = get_ecg_with_split('112e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_112e12, self.cs_112e12 = get_ecg_with_split('112e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_112e06, self.cs_112e06 = get_ecg_with_split('112e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_112e00, self.cs_112e00 = get_ecg_with_split('112e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_112en6, self.cs_112en6 = get_ecg_with_split('112e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_113e24, self.cs_113e24 = get_ecg_with_split('113e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_113e18, self.cs_113e18 = get_ecg_with_split('113e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_113e12, self.cs_113e12 = get_ecg_with_split('113e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_113e06, self.cs_113e06 = get_ecg_with_split('113e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_113e00, self.cs_113e00 = get_ecg_with_split('113e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_113en6, self.cs_113en6 = get_ecg_with_split('113e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_114e24, self.cs_114e24 = get_ecg_with_split('114e24', samp_freq,channel=1, norm_type=norm_type)
#         self.ns_114e18, self.cs_114e18 = get_ecg_with_split('114e18', samp_freq,channel=1, norm_type=norm_type)
#         self.ns_114e12, self.cs_114e12 = get_ecg_with_split('114e12', samp_freq,channel=1, norm_type=norm_type)
#         self.ns_114e06, self.cs_114e06 = get_ecg_with_split('114e06', samp_freq,channel=1, norm_type=norm_type)
#         self.ns_114e00, self.cs_114e00 = get_ecg_with_split('114e00', samp_freq,channel=1, norm_type=norm_type)
#         self.ns_114en6, self.cs_114en6 = get_ecg_with_split('114e_6', samp_freq,channel=1, norm_type=norm_type)
        
#         self.ns_115e24, self.cs_115e24 = get_ecg_with_split('115e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_115e18, self.cs_115e18 = get_ecg_with_split('115e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_115e12, self.cs_115e12 = get_ecg_with_split('115e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_115e06, self.cs_115e06 = get_ecg_with_split('115e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_115e00, self.cs_115e00 = get_ecg_with_split('115e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_115en6, self.cs_115en6 = get_ecg_with_split('115e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_116e24, self.cs_116e24 = get_ecg_with_split('116e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_116e18, self.cs_116e18 = get_ecg_with_split('116e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_116e12, self.cs_116e12 = get_ecg_with_split('116e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_116e06, self.cs_116e06 = get_ecg_with_split('116e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_116e00, self.cs_116e00 = get_ecg_with_split('116e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_116en6, self.cs_116en6 = get_ecg_with_split('116e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_117e24, self.cs_117e24 = get_ecg_with_split('117e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_117e18, self.cs_117e18 = get_ecg_with_split('117e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_117e12, self.cs_117e12 = get_ecg_with_split('117e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_117e06, self.cs_117e06 = get_ecg_with_split('117e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_117e00, self.cs_117e00 = get_ecg_with_split('117e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_117en6, self.cs_117en6 = get_ecg_with_split('117e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_118e24, self.cs_118e24 = get_ecg_with_split('118e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_118e18, self.cs_118e18 = get_ecg_with_split('118e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_118e12, self.cs_118e12 = get_ecg_with_split('118e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_118e06, self.cs_118e06 = get_ecg_with_split('118e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_118e00, self.cs_118e00 = get_ecg_with_split('118e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_118en6, self.cs_118en6 = get_ecg_with_split('118e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_119e24, self.cs_119e24 = get_ecg_with_split('119e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_119e18, self.cs_119e18 = get_ecg_with_split('119e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_119e12, self.cs_119e12 = get_ecg_with_split('119e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_119e06, self.cs_119e06 = get_ecg_with_split('119e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_119e00, self.cs_119e00 = get_ecg_with_split('119e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_119en6, self.cs_119en6 = get_ecg_with_split('119e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_121e24, self.cs_121e24 = get_ecg_with_split('121e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_121e18, self.cs_121e18 = get_ecg_with_split('121e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_121e12, self.cs_121e12 = get_ecg_with_split('121e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_121e06, self.cs_121e06 = get_ecg_with_split('121e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_121e00, self.cs_121e00 = get_ecg_with_split('121e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_121en6, self.cs_121en6 = get_ecg_with_split('121e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_122e24, self.cs_122e24 = get_ecg_with_split('122e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_122e18, self.cs_122e18 = get_ecg_with_split('122e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_122e12, self.cs_122e12 = get_ecg_with_split('122e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_122e06, self.cs_122e06 = get_ecg_with_split('122e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_122e00, self.cs_122e00 = get_ecg_with_split('122e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_122en6, self.cs_122en6 = get_ecg_with_split('122e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_124e24, self.cs_124e24 = get_ecg_with_split('124e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_124e18, self.cs_124e18 = get_ecg_with_split('124e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_124e12, self.cs_124e12 = get_ecg_with_split('124e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_124e06, self.cs_124e06 = get_ecg_with_split('124e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_124e00, self.cs_124e00 = get_ecg_with_split('124e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_124en6, self.cs_124en6 = get_ecg_with_split('124e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_200e24, self.cs_200e24 = get_ecg_with_split('200e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_200e18, self.cs_200e18 = get_ecg_with_split('200e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_200e12, self.cs_200e12 = get_ecg_with_split('200e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_200e06, self.cs_200e06 = get_ecg_with_split('200e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_200e00, self.cs_200e00 = get_ecg_with_split('200e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_200en6, self.cs_200en6 = get_ecg_with_split('200e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_201e24, self.cs_201e24 = get_ecg_with_split('201e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_201e18, self.cs_201e18 = get_ecg_with_split('201e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_201e12, self.cs_201e12 = get_ecg_with_split('201e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_201e06, self.cs_201e06 = get_ecg_with_split('201e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_201e00, self.cs_201e00 = get_ecg_with_split('201e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_201en6, self.cs_201en6 = get_ecg_with_split('201e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_202e24, self.cs_202e24 = get_ecg_with_split('202e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_202e18, self.cs_202e18 = get_ecg_with_split('202e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_202e12, self.cs_202e12 = get_ecg_with_split('202e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_202e06, self.cs_202e06 = get_ecg_with_split('202e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_202e00, self.cs_202e00 = get_ecg_with_split('202e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_202en6, self.cs_202en6 = get_ecg_with_split('202e_6', samp_freq,channel=0, norm_type=norm_type)
                
#         self.ns_203e24, self.cs_203e24 = get_ecg_with_split('203e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_203e18, self.cs_203e18 = get_ecg_with_split('203e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_203e12, self.cs_203e12 = get_ecg_with_split('203e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_203e06, self.cs_203e06 = get_ecg_with_split('203e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_203e00, self.cs_203e00 = get_ecg_with_split('203e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_203en6, self.cs_203en6 = get_ecg_with_split('203e_6', samp_freq,channel=0, norm_type=norm_type)
                
#         self.ns_205e24, self.cs_205e24 = get_ecg_with_split('205e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_205e18, self.cs_205e18 = get_ecg_with_split('205e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_205e12, self.cs_205e12 = get_ecg_with_split('205e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_205e06, self.cs_205e06 = get_ecg_with_split('205e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_205e00, self.cs_205e00 = get_ecg_with_split('205e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_205en6, self.cs_205en6 = get_ecg_with_split('205e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_207e24, self.cs_207e24 = get_ecg_with_split('207e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_207e18, self.cs_207e18 = get_ecg_with_split('207e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_207e12, self.cs_207e12 = get_ecg_with_split('207e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_207e06, self.cs_207e06 = get_ecg_with_split('207e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_207e00, self.cs_207e00 = get_ecg_with_split('207e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_207en6, self.cs_207en6 = get_ecg_with_split('207e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_208e24, self.cs_208e24 = get_ecg_with_split('208e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_208e18, self.cs_208e18 = get_ecg_with_split('208e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_208e12, self.cs_208e12 = get_ecg_with_split('208e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_208e06, self.cs_208e06 = get_ecg_with_split('208e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_208e00, self.cs_208e00 = get_ecg_with_split('208e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_208en6, self.cs_208en6 = get_ecg_with_split('208e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_209e24, self.cs_209e24 = get_ecg_with_split('209e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_209e18, self.cs_209e18 = get_ecg_with_split('209e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_209e12, self.cs_209e12 = get_ecg_with_split('209e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_209e06, self.cs_209e06 = get_ecg_with_split('209e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_209e00, self.cs_209e00 = get_ecg_with_split('209e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_209en6, self.cs_209en6 = get_ecg_with_split('209e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_210e24, self.cs_210e24 = get_ecg_with_split('210e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_210e18, self.cs_210e18 = get_ecg_with_split('210e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_210e12, self.cs_210e12 = get_ecg_with_split('210e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_210e06, self.cs_210e06 = get_ecg_with_split('210e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_210e00, self.cs_210e00 = get_ecg_with_split('210e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_210en6, self.cs_210en6 = get_ecg_with_split('210e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_212e24, self.cs_212e24 = get_ecg_with_split('212e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_212e18, self.cs_212e18 = get_ecg_with_split('212e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_212e12, self.cs_212e12 = get_ecg_with_split('212e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_212e06, self.cs_212e06 = get_ecg_with_split('212e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_212e00, self.cs_212e00 = get_ecg_with_split('212e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_212en6, self.cs_212en6 = get_ecg_with_split('212e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_213e24, self.cs_213e24 = get_ecg_with_split('213e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_213e18, self.cs_213e18 = get_ecg_with_split('213e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_213e12, self.cs_213e12 = get_ecg_with_split('213e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_213e06, self.cs_213e06 = get_ecg_with_split('213e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_213e00, self.cs_213e00 = get_ecg_with_split('213e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_213en6, self.cs_213en6 = get_ecg_with_split('213e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_214e24, self.cs_214e24 = get_ecg_with_split('214e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_214e18, self.cs_214e18 = get_ecg_with_split('214e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_214e12, self.cs_214e12 = get_ecg_with_split('214e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_214e06, self.cs_214e06 = get_ecg_with_split('214e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_214e00, self.cs_214e00 = get_ecg_with_split('214e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_214en6, self.cs_214en6 = get_ecg_with_split('214e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_215e24, self.cs_215e24 = get_ecg_with_split('215e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_215e18, self.cs_215e18 = get_ecg_with_split('215e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_215e12, self.cs_215e12 = get_ecg_with_split('215e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_215e06, self.cs_215e06 = get_ecg_with_split('215e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_215e00, self.cs_215e00 = get_ecg_with_split('215e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_215en6, self.cs_215en6 = get_ecg_with_split('215e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_217e24, self.cs_217e24 = get_ecg_with_split('217e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_217e18, self.cs_217e18 = get_ecg_with_split('217e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_217e12, self.cs_217e12 = get_ecg_with_split('217e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_217e06, self.cs_217e06 = get_ecg_with_split('217e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_217e00, self.cs_217e00 = get_ecg_with_split('217e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_217en6, self.cs_217en6 = get_ecg_with_split('217e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_219e24, self.cs_219e24 = get_ecg_with_split('219e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_219e18, self.cs_219e18 = get_ecg_with_split('219e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_219e12, self.cs_219e12 = get_ecg_with_split('219e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_219e06, self.cs_219e06 = get_ecg_with_split('219e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_219e00, self.cs_219e00 = get_ecg_with_split('219e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_219en6, self.cs_219en6 = get_ecg_with_split('219e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_220e24, self.cs_220e24 = get_ecg_with_split('220e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_220e18, self.cs_220e18 = get_ecg_with_split('220e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_220e12, self.cs_220e12 = get_ecg_with_split('220e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_220e06, self.cs_220e06 = get_ecg_with_split('220e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_220e00, self.cs_220e00 = get_ecg_with_split('220e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_220en6, self.cs_220en6 = get_ecg_with_split('220e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_221e24, self.cs_221e24 = get_ecg_with_split('221e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_221e18, self.cs_221e18 = get_ecg_with_split('221e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_221e12, self.cs_221e12 = get_ecg_with_split('221e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_221e06, self.cs_221e06 = get_ecg_with_split('221e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_221e00, self.cs_221e00 = get_ecg_with_split('221e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_221en6, self.cs_221en6 = get_ecg_with_split('221e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_222e24, self.cs_222e24 = get_ecg_with_split('222e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_222e18, self.cs_222e18 = get_ecg_with_split('222e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_222e12, self.cs_222e12 = get_ecg_with_split('222e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_222e06, self.cs_222e06 = get_ecg_with_split('222e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_222e00, self.cs_222e00 = get_ecg_with_split('222e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_222en6, self.cs_222en6 = get_ecg_with_split('222e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_223e24, self.cs_223e24 = get_ecg_with_split('223e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_223e18, self.cs_223e18 = get_ecg_with_split('223e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_223e12, self.cs_223e12 = get_ecg_with_split('223e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_223e06, self.cs_223e06 = get_ecg_with_split('223e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_223e00, self.cs_223e00 = get_ecg_with_split('223e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_223en6, self.cs_223en6 = get_ecg_with_split('223e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_228e24, self.cs_228e24 = get_ecg_with_split('228e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_228e18, self.cs_228e18 = get_ecg_with_split('228e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_228e12, self.cs_228e12 = get_ecg_with_split('228e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_228e06, self.cs_228e06 = get_ecg_with_split('228e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_228e00, self.cs_228e00 = get_ecg_with_split('228e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_228en6, self.cs_228en6 = get_ecg_with_split('228e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_230e24, self.cs_230e24 = get_ecg_with_split('230e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_230e18, self.cs_230e18 = get_ecg_with_split('230e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_230e12, self.cs_230e12 = get_ecg_with_split('230e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_230e06, self.cs_230e06 = get_ecg_with_split('230e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_230e00, self.cs_230e00 = get_ecg_with_split('230e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_230en6, self.cs_230en6 = get_ecg_with_split('230e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_231e24, self.cs_231e24 = get_ecg_with_split('231e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_231e18, self.cs_231e18 = get_ecg_with_split('231e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_231e12, self.cs_231e12 = get_ecg_with_split('231e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_231e06, self.cs_231e06 = get_ecg_with_split('231e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_231e00, self.cs_231e00 = get_ecg_with_split('231e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_231en6, self.cs_231en6 = get_ecg_with_split('231e_6', samp_freq,channel=0, norm_type=norm_type)

#         self.ns_232e24, self.cs_232e24 = get_ecg_with_split('232e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_232e18, self.cs_232e18 = get_ecg_with_split('232e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_232e12, self.cs_232e12 = get_ecg_with_split('232e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_232e06, self.cs_232e06 = get_ecg_with_split('232e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_232e00, self.cs_232e00 = get_ecg_with_split('232e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_232en6, self.cs_232en6 = get_ecg_with_split('232e_6', samp_freq,channel=0, norm_type=norm_type)
        
#         self.ns_234e24, self.cs_234e24 = get_ecg_with_split('234e24', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_234e18, self.cs_234e18 = get_ecg_with_split('234e18', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_234e12, self.cs_234e12 = get_ecg_with_split('234e12', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_234e06, self.cs_234e06 = get_ecg_with_split('234e06', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_234e00, self.cs_234e00 = get_ecg_with_split('234e00', samp_freq,channel=0, norm_type=norm_type)
#         self.ns_234en6, self.cs_234en6 = get_ecg_with_split('234e_6', samp_freq,channel=0, norm_type=norm_type)

class ecg_split_data_sets:
    """
    Loads a bit faster than the other one

    Uses each existing ECG record, then proceeds to use signals from 5 minute onwards then splits them into the alternating
    noisy/clean segments as stated by the MIT-BIH NST generator script.

    Returns::    
        (nd array) : ns_1xxeyy, cs_1xxeyy where x is record no. and y is noise level (from n6 to 24)


    Parameters::
        samp_freq (int): sampling frequency used by the record (default 360)
        norm_type (str): chunks, all, none/''
    """
    def __init__(self, samp_freq=360, norm_type='none'):
        self.ns_100e03, self.cs_100e03 = get_ecg_with_split('100e03', samp_freq, channel=0,norm_type=norm_type)
        self.ns_101e03, self.cs_101e03 = get_ecg_with_split('101e03', samp_freq,channel=0, norm_type=norm_type)        
        self.ns_103e03, self.cs_103e03 = get_ecg_with_split('103e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_105e03, self.cs_105e03 = get_ecg_with_split('105e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_106e03, self.cs_106e03 = get_ecg_with_split('106e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_107e03, self.cs_107e03 = get_ecg_with_split('107e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_108e03, self.cs_108e03 = get_ecg_with_split('108e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_109e03, self.cs_109e03 = get_ecg_with_split('109e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_111e03, self.cs_111e03 = get_ecg_with_split('111e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_112e03, self.cs_112e03 = get_ecg_with_split('112e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_113e03, self.cs_113e03 = get_ecg_with_split('113e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_114e03, self.cs_114e03 = get_ecg_with_split('114e03', samp_freq,channel=1, norm_type=norm_type)
        self.ns_115e03, self.cs_115e03 = get_ecg_with_split('115e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_116e03, self.cs_116e03 = get_ecg_with_split('116e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_117e03, self.cs_117e03 = get_ecg_with_split('117e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_118e03, self.cs_118e03 = get_ecg_with_split('118e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_119e03, self.cs_119e03 = get_ecg_with_split('119e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_121e03, self.cs_121e03 = get_ecg_with_split('121e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_122e03, self.cs_122e03 = get_ecg_with_split('122e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_124e03, self.cs_124e03 = get_ecg_with_split('124e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_200e03, self.cs_200e03 = get_ecg_with_split('200e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_201e03, self.cs_201e03 = get_ecg_with_split('201e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_202e03, self.cs_202e03 = get_ecg_with_split('202e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_203e03, self.cs_203e03 = get_ecg_with_split('203e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_205e03, self.cs_205e03 = get_ecg_with_split('205e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_207e03, self.cs_207e03 = get_ecg_with_split('207e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_208e03, self.cs_208e03 = get_ecg_with_split('208e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_209e03, self.cs_209e03 = get_ecg_with_split('209e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_210e03, self.cs_210e03 = get_ecg_with_split('210e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_212e03, self.cs_212e03 = get_ecg_with_split('212e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_213e03, self.cs_213e03 = get_ecg_with_split('213e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_214e03, self.cs_214e03 = get_ecg_with_split('214e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_215e03, self.cs_215e03 = get_ecg_with_split('215e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_217e03, self.cs_217e03 = get_ecg_with_split('217e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_219e03, self.cs_219e03 = get_ecg_with_split('219e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_220e03, self.cs_220e03 = get_ecg_with_split('220e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_221e03, self.cs_221e03 = get_ecg_with_split('221e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_222e03, self.cs_222e03 = get_ecg_with_split('222e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_223e03, self.cs_223e03 = get_ecg_with_split('223e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_228e03, self.cs_228e03 = get_ecg_with_split('228e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_230e03, self.cs_230e03 = get_ecg_with_split('230e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_231e03, self.cs_231e03 = get_ecg_with_split('231e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_232e03, self.cs_232e03 = get_ecg_with_split('232e03', samp_freq,channel=0, norm_type=norm_type)
        self.ns_234e03, self.cs_234e03 = get_ecg_with_split('234e03', samp_freq,channel=0, norm_type=norm_type)
        
