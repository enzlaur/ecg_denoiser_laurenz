# ecg_thesis_code
New clean repository for thesis

# Notes
> Runtime for creating a new model with cuda is around 30 mins (40-50 mins using CPU only).